﻿namespace UseBackgroundWorker
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.dowloadButton = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.SuspendLayout();
            // 
            // dowloadButton
            // 
            this.dowloadButton.Location = new System.Drawing.Point(59, 59);
            this.dowloadButton.Name = "dowloadButton";
            this.dowloadButton.Size = new System.Drawing.Size(75, 23);
            this.dowloadButton.TabIndex = 0;
            this.dowloadButton.Text = "下载";
            this.dowloadButton.UseVisualStyleBackColor = true;
            this.dowloadButton.Click += new System.EventHandler(this.dowloadButton_Click);
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker1_RunWorkerCompleted);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 145);
            this.Controls.Add(this.dowloadButton);
            this.Name = "Form1";
            this.Text = "BackgroundWorker示例";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button dowloadButton;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}

