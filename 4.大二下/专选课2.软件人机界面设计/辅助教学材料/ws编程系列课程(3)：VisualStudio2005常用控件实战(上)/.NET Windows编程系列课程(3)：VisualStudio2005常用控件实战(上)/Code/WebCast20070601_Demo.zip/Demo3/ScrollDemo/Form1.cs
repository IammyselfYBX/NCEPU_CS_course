﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ScrollDemo
{
    public partial class Form1 : Form
    {
        Color backColor = Color.Black;
        public Form1()
        {
            InitializeComponent();
        }
        private void vsb_ValueChanged(object sender, EventArgs e)
        {
            int nR, nG, nB;
            nR = vsbRed.Value;
            nG = vsbGreen.Value;
            nB = vsbBlue.Value;
            backColor = Color.FromArgb(nR, nG, nB);
            lbRed.Text = nR.ToString();
            lbGreen.Text = nG.ToString();
            lbBlue.Text = nB.ToString();
            btnShow.BackColor = backColor;
            Invalidate(false);

        }
    }
}