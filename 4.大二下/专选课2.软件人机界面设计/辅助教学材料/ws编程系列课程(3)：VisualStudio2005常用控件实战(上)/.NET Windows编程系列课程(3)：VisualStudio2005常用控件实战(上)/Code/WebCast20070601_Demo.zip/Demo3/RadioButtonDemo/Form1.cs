﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RadioButtonDemo
{
    public partial class Form1 : Form
    {
        private Color curColor;
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radio = (RadioButton)sender;
            if (radio.Checked)
            {
                curColor = Color.FromName(radio.Text);
                Invalidate(false);
            }

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (cbFill.Checked)
            {
                btnShow.BackColor = curColor;
            }
        }
    }
}