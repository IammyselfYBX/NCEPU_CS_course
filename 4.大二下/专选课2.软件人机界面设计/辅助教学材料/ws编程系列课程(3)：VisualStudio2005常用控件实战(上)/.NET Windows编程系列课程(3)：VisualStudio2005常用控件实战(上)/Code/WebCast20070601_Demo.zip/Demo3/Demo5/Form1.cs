﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Demo5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //添加变量
        private int nPrevValue = 0;//上一次值
        private bool bAppend = true;//用户按的数字是否连接在显示的数字后面
        private string strPrevOpar = "";//上一次的操作符号

        //处理按钮"C"
        private void btnClear_Click(object sender, EventArgs e)
        {
            tbShow.Text = "0";
            strPrevOpar = "";
            bAppend = true;
            nPrevValue = 0;
        }

        //处理数字键
        private void Num_Click(object sender, System.EventArgs e)
        {

            string strNum = ((System.Windows.Forms.Button)sender).Text;
            if (bAppend)
                tbShow.Text = int.Parse(tbShow.Text + strNum).ToString();
            else
            {
                tbShow.Text = strNum;
                bAppend = true;
            }
        }

        //处理操作符号
        private void Opar_Click(object sender, System.EventArgs e)
        {
            if (tbShow.Text == "")
                return;
            int nCurValue = int.Parse(tbShow.Text); ;
            switch (strPrevOpar)
            {
                case "+":
                    nCurValue += nPrevValue;
                    break;
                case "-":
                    nCurValue = nPrevValue - nCurValue;
                    break;
                case "*":
                    nCurValue *= nPrevValue;
                    break;
                case "/":
                    nCurValue = nPrevValue / nCurValue;
                    break;
                default:
                    break;
            }
            strPrevOpar = ((Button)sender).Text;
            bAppend = false;
            tbShow.Text = nCurValue.ToString();
            nPrevValue = nCurValue;

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {

            System.Drawing.Drawing2D.GraphicsPath shape = new System.Drawing.Drawing2D.GraphicsPath();
            shape.AddEllipse(0, 0, this.Width, this.Height);
            this.Region = new System.Drawing.Region(shape);

        }

    }
}