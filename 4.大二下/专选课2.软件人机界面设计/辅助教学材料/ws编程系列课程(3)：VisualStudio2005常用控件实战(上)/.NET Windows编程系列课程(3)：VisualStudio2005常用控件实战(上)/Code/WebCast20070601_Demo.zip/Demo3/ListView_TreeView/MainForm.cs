using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;//�������ã���ʹ���ļ���Ŀ¼��

namespace ListView_TreeView
{
	/// <summary>
	/// ʹ��Treeview��ListViewʾ����������Windows��Դ������Ч��
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Panel panelLeft;
		private System.Windows.Forms.Panel panelRight;
		private System.Windows.Forms.Splitter splitter;
		private System.Windows.Forms.TreeView DirectoryTreeView;
		private System.Windows.Forms.ListView FileListView;
		private System.Windows.Forms.ImageList imageList;
		private System.Windows.Forms.ColumnHeader ModifiedTime;
		private System.ComponentModel.IContainer components;

		private float fProportion = 0.5f;
		private System.Windows.Forms.ColumnHeader FileName;
		private System.Windows.Forms.ColumnHeader FileSize;
		private System.Windows.Forms.ColumnHeader FileType;
		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItemLargeIcon;
		private System.Windows.Forms.MenuItem menuItemSmallIcon;
		private System.Windows.Forms.MenuItem menuItemList;
		private System.Windows.Forms.MenuItem menuItemDetail;
		private string strDirectory;

		public MainForm()
		{
			//
			// Windows ���������֧���������
			//
			InitializeComponent();
			OnResize(EventArgs.Empty);
			RefreshTree();
			//
			// TODO: �� InitializeComponent ���ú������κι��캯������
			//
		}

		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.panelLeft = new System.Windows.Forms.Panel();
			this.DirectoryTreeView = new System.Windows.Forms.TreeView();
			this.imageList = new System.Windows.Forms.ImageList(this.components);
			this.splitter = new System.Windows.Forms.Splitter();
			this.panelRight = new System.Windows.Forms.Panel();
			this.FileListView = new System.Windows.Forms.ListView();
			this.FileName = new System.Windows.Forms.ColumnHeader();
			this.FileSize = new System.Windows.Forms.ColumnHeader();
			this.FileType = new System.Windows.Forms.ColumnHeader();
			this.ModifiedTime = new System.Windows.Forms.ColumnHeader();
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItemLargeIcon = new System.Windows.Forms.MenuItem();
			this.menuItemSmallIcon = new System.Windows.Forms.MenuItem();
			this.menuItemList = new System.Windows.Forms.MenuItem();
			this.menuItemDetail = new System.Windows.Forms.MenuItem();
			this.panelLeft.SuspendLayout();
			this.panelRight.SuspendLayout();
			this.SuspendLayout();
			// 
			// panelLeft
			// 
			this.panelLeft.BackColor = System.Drawing.SystemColors.Desktop;
			this.panelLeft.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panelLeft.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.DirectoryTreeView});
			this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
			this.panelLeft.Name = "panelLeft";
			this.panelLeft.Size = new System.Drawing.Size(264, 273);
			this.panelLeft.TabIndex = 0;
			this.panelLeft.Resize += new System.EventHandler(this.PanelOnResize);
			// 
			// DirectoryTreeView
			// 
			this.DirectoryTreeView.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.DirectoryTreeView.ImageList = this.imageList;
			this.DirectoryTreeView.Name = "DirectoryTreeView";
			this.DirectoryTreeView.Size = new System.Drawing.Size(264, 272);
			this.DirectoryTreeView.TabIndex = 0;
			this.DirectoryTreeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.DirectoryTreeView_AfterSelect);
			this.DirectoryTreeView.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.DirectoryTreeView_BeforeExpand);
			// 
			// imageList
			// 
			this.imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.imageList.ImageSize = new System.Drawing.Size(16, 16);
			this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
			this.imageList.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// splitter
			// 
			this.splitter.Location = new System.Drawing.Point(264, 0);
			this.splitter.Name = "splitter";
			this.splitter.Size = new System.Drawing.Size(4, 273);
			this.splitter.TabIndex = 1;
			this.splitter.TabStop = false;
			this.splitter.SplitterMoving += new System.Windows.Forms.SplitterEventHandler(this.splitter_SplitterMoving);
			// 
			// panelRight
			// 
			this.panelRight.BackColor = System.Drawing.SystemColors.HotTrack;
			this.panelRight.Controls.AddRange(new System.Windows.Forms.Control[] {
																					 this.FileListView});
			this.panelRight.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panelRight.Location = new System.Drawing.Point(268, 0);
			this.panelRight.Name = "panelRight";
			this.panelRight.Size = new System.Drawing.Size(460, 273);
			this.panelRight.TabIndex = 2;
			this.panelRight.Resize += new System.EventHandler(this.PanelOnResize);
			// 
			// FileListView
			// 
			this.FileListView.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.FileListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						   this.FileName,
																						   this.FileSize,
																						   this.FileType,
																						   this.ModifiedTime});
			this.FileListView.Name = "FileListView";
			this.FileListView.Size = new System.Drawing.Size(464, 272);
			this.FileListView.SmallImageList = this.imageList;
			this.FileListView.TabIndex = 0;
			this.FileListView.View = System.Windows.Forms.View.Details;
			// 
			// FileName
			// 
			this.FileName.Text = "����";
			this.FileName.Width = 100;
			// 
			// FileSize
			// 
			this.FileSize.Text = "��С";
			this.FileSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.FileSize.Width = 100;
			// 
			// FileType
			// 
			this.FileType.Text = "����";
			// 
			// ModifiedTime
			// 
			this.ModifiedTime.Text = "�޸�ʱ��";
			this.ModifiedTime.Width = 200;
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuItem1});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItemLargeIcon,
																					  this.menuItemSmallIcon,
																					  this.menuItemList,
																					  this.menuItemDetail});
			this.menuItem1.Text = "�鿴(&V)";
			// 
			// menuItemLargeIcon
			// 
			this.menuItemLargeIcon.Index = 0;
			this.menuItemLargeIcon.Text = "��ͼ��(&G)";
			this.menuItemLargeIcon.Click += new System.EventHandler(this.menuItemLargeIcon_Click);
			// 
			// menuItemSmallIcon
			// 
			this.menuItemSmallIcon.Index = 1;
			this.menuItemSmallIcon.Text = "Сͼ��(&M)";
			this.menuItemSmallIcon.Click += new System.EventHandler(this.menuItemSmallIcon_Click);
			// 
			// menuItemList
			// 
			this.menuItemList.Index = 2;
			this.menuItemList.Text = "�б�(&L)";
			this.menuItemList.Click += new System.EventHandler(this.menuItemList_Click);
			// 
			// menuItemDetail
			// 
			this.menuItemDetail.Index = 3;
			this.menuItemDetail.Text = "��ϸ����(&D)";
			this.menuItemDetail.Click += new System.EventHandler(this.menuItemDetail_Click);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.ClientSize = new System.Drawing.Size(728, 273);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panelRight,
																		  this.splitter,
																		  this.panelLeft});
			this.Menu = this.mainMenu;
			this.Name = "MainForm";
			this.Text = "ListView_TreeViewʹ��ʾ��";
			this.panelLeft.ResumeLayout(false);
			this.panelRight.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Ӧ�ó��������ڵ㡣
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new MainForm());
		}

		/// <summary>
		/// ���º���Ϊ���Ĵ�С�仯��Ӧ����
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void PanelOnResize(object sender, System.EventArgs e)
		{
			((Panel)sender).Invalidate();
		}
		/// <summary>
		/// ���º��������ָ����ƶ��¼�
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void splitter_SplitterMoving(object sender, System.Windows.Forms.SplitterEventArgs e)
		{
			fProportion = (float)e.SplitX/ClientSize.Width;
		}
		/// <summary>
		/// ����Form��OnResize�¼�
		/// </summary>
		/// <param name="e"></param>
		protected override void OnResize(System.EventArgs e)
		{
			base.OnResize(e);
			panelRight.Width = (int)(fProportion*ClientSize.Width);
		}
		/// <summary>
		/// ��ʼ�������TreeView��ʾ
		/// </summary>
		public void RefreshTree()
		{
			// Turn off visual updating and clear tree.

			DirectoryTreeView.BeginUpdate();
			DirectoryTreeView.Nodes.Clear();

			// Make disk drives the root nodes. 

			string[] astrDrives = Directory.GetLogicalDrives();

			foreach (string str in astrDrives)
			{
				TreeNode tnDrive = new TreeNode(str, 0, 0);
				DirectoryTreeView.Nodes.Add(tnDrive);
				AddDirectories(tnDrive);

				if (str == "C:\\")
					DirectoryTreeView.SelectedNode = tnDrive;
			}
			DirectoryTreeView.EndUpdate();
		}
		/// <summary>
		/// ���Ӹ����������ڵ�
		/// </summary>
		/// <param name="tn"></param>
		void AddDirectories(TreeNode tn)
		{
			tn.Nodes.Clear();

			string          strPath = tn.FullPath;
			DirectoryInfo   dirinfo = new DirectoryInfo(strPath);
			DirectoryInfo[] adirinfo;

			try
			{
				adirinfo = dirinfo.GetDirectories();
			}
			catch
			{
				return;
			}

			foreach (DirectoryInfo di in adirinfo)
			{
				TreeNode tnDir = new TreeNode(di.Name, 1, 2);
				tn.Nodes.Add(tnDir);
			}
		}
		/// <summary>
		/// ΪTreeView��BeforeExpand��Ӧ�¼������ڽڵ��ǰִ��
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void DirectoryTreeView_BeforeExpand(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			DirectoryTreeView.BeginUpdate();

			foreach (TreeNode tn in e.Node.Nodes)
				AddDirectories(tn);

			DirectoryTreeView.EndUpdate();
		}
		/// <summary>
		/// ���ListView����ʾ�ļ���Ϣ
		/// </summary>
		/// <param name="strDirectory"></param>
		public void ShowFiles(string strDirectory)
		{
			// Save directory name as field.
               
			this.strDirectory = strDirectory;

			FileListView.Items.Clear();
			DirectoryInfo dirinfo = new DirectoryInfo(strDirectory);
			FileInfo[] afileinfo;

			try
			{
				afileinfo = dirinfo.GetFiles();
			}
			catch
			{
				return;
			}

			foreach (FileInfo fi in afileinfo)
			{
				// Create ListViewItem.

				ListViewItem lvi = new ListViewItem(fi.Name);

				// Assign ImageIndex based on filename extension.

				if (Path.GetExtension(fi.Name).ToUpper() == ".EXE")
					lvi.ImageIndex = 4;
				else
					lvi.ImageIndex = 3;

				// Add file length and modified time sub-items.

				lvi.SubItems.Add(fi.Length.ToString("N0"));
				
				// Add attribute subitem.

				string strAttr = "";
               
				if ((fi.Attributes & FileAttributes.Archive) != 0)
					strAttr += "A";

				if ((fi.Attributes & FileAttributes.Hidden) != 0)
					strAttr += "H";

				if ((fi.Attributes & FileAttributes.ReadOnly) != 0)
					strAttr += "R";

				if ((fi.Attributes & FileAttributes.System) != 0)
					strAttr += "S";

				lvi.SubItems.Add(strAttr);

				lvi.SubItems.Add(fi.LastWriteTime.ToString());

				// Add completed ListViewItem to FileListView.

				FileListView.Items.Add(lvi);
			}
		}

		/// <summary>
		/// ��TreeView�ؼ�AfterSelect�¼���Ӧ����ѡ������ڵ����������ListView
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void DirectoryTreeView_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			ShowFiles(e.Node.FullPath);
		}
		//�����ĸ�����Ϊ�˵���Ӧ�¼�
		private void menuItemLargeIcon_Click(object sender, System.EventArgs e)
		{
			FileListView.View = View.LargeIcon;
		}
		private void menuItemSmallIcon_Click(object sender, System.EventArgs e)
		{
			FileListView.View = View.SmallIcon;
		
		}

		private void menuItemList_Click(object sender, System.EventArgs e)
		{
			FileListView.View = View.List;
		}
		private void menuItemDetail_Click(object sender, System.EventArgs e)
		{
			FileListView.View = View.Details;
		}
	}
}
