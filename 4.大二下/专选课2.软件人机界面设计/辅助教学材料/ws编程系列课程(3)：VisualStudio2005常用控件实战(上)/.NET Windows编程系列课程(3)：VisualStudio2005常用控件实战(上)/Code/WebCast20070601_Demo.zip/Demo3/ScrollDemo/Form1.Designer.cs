﻿namespace ScrollDemo
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbBlue = new System.Windows.Forms.Label();
            this.lbGreen = new System.Windows.Forms.Label();
            this.lbRed = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.vsbBlue = new System.Windows.Forms.VScrollBar();
            this.vsbGreen = new System.Windows.Forms.VScrollBar();
            this.vsbRed = new System.Windows.Forms.VScrollBar();
            this.btnShow = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbBlue);
            this.groupBox1.Controls.Add(this.lbGreen);
            this.groupBox1.Controls.Add(this.lbRed);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.vsbBlue);
            this.groupBox1.Controls.Add(this.vsbGreen);
            this.groupBox1.Controls.Add(this.vsbRed);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(155, 280);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // lbBlue
            // 
            this.lbBlue.AutoSize = true;
            this.lbBlue.Location = new System.Drawing.Point(118, 234);
            this.lbBlue.Name = "lbBlue";
            this.lbBlue.Size = new System.Drawing.Size(11, 12);
            this.lbBlue.TabIndex = 8;
            this.lbBlue.Text = "0";
            // 
            // lbGreen
            // 
            this.lbGreen.AutoSize = true;
            this.lbGreen.Location = new System.Drawing.Point(66, 234);
            this.lbGreen.Name = "lbGreen";
            this.lbGreen.Size = new System.Drawing.Size(11, 12);
            this.lbGreen.TabIndex = 7;
            this.lbGreen.Text = "0";
            // 
            // lbRed
            // 
            this.lbRed.AutoSize = true;
            this.lbRed.Location = new System.Drawing.Point(15, 234);
            this.lbRed.Name = "lbRed";
            this.lbRed.Size = new System.Drawing.Size(11, 12);
            this.lbRed.TabIndex = 6;
            this.lbRed.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(114, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "蓝";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(63, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "绿";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "红";
            // 
            // vsbBlue
            // 
            this.vsbBlue.LargeChange = 1;
            this.vsbBlue.Location = new System.Drawing.Point(117, 39);
            this.vsbBlue.Maximum = 255;
            this.vsbBlue.Name = "vsbBlue";
            this.vsbBlue.Size = new System.Drawing.Size(18, 174);
            this.vsbBlue.TabIndex = 2;
            this.vsbBlue.ValueChanged += new System.EventHandler(this.vsb_ValueChanged);
            // 
            // vsbGreen
            // 
            this.vsbGreen.LargeChange = 1;
            this.vsbGreen.Location = new System.Drawing.Point(65, 39);
            this.vsbGreen.Maximum = 255;
            this.vsbGreen.Name = "vsbGreen";
            this.vsbGreen.Size = new System.Drawing.Size(18, 174);
            this.vsbGreen.TabIndex = 1;
            this.vsbGreen.ValueChanged += new System.EventHandler(this.vsb_ValueChanged);
            // 
            // vsbRed
            // 
            this.vsbRed.LargeChange = 1;
            this.vsbRed.Location = new System.Drawing.Point(17, 39);
            this.vsbRed.Maximum = 255;
            this.vsbRed.Name = "vsbRed";
            this.vsbRed.Size = new System.Drawing.Size(18, 174);
            this.vsbRed.TabIndex = 0;
            this.vsbRed.ValueChanged += new System.EventHandler(this.vsb_ValueChanged);
            // 
            // btnShow
            // 
            this.btnShow.Enabled = false;
            this.btnShow.Location = new System.Drawing.Point(194, 23);
            this.btnShow.Name = "btnShow";
            this.btnShow.Size = new System.Drawing.Size(86, 238);
            this.btnShow.TabIndex = 2;
            this.btnShow.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 304);
            this.Controls.Add(this.btnShow);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "滚动条示例";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbBlue;
        private System.Windows.Forms.Label lbGreen;
        private System.Windows.Forms.Label lbRed;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.VScrollBar vsbBlue;
        private System.Windows.Forms.VScrollBar vsbGreen;
        private System.Windows.Forms.VScrollBar vsbRed;
        private System.Windows.Forms.Button btnShow;
    }
}

