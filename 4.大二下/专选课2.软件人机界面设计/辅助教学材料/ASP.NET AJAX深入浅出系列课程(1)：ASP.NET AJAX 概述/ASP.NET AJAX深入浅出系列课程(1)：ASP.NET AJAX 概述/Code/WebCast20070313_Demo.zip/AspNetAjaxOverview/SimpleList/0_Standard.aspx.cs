using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class SimpleList_0_Standard : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
		TimerMessage.Text = DateTime.Now.ToLongTimeString();
		if (!IsPostBack)
		{
			ViewState["CurrentTab"] = "0";
		}
	}

	protected void AddListBtn_Click(object sender, EventArgs e)
	{
		using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["SimpleListsConnectionString"].ConnectionString))
		{
			SqlCommand cmd = new SqlCommand(
				"INSERT INTO Lists(Name) VALUES(@Name)", cn);
			cmd.Parameters.Add("Name", AddItemTxt.Text);
			cn.Open();
			cmd.ExecuteNonQuery();
		}
		ListGrid.DataBind();
		AddItemTxt.Text = "";
	}

	protected string FormatPriority(int priority)
	{
		switch (priority)
		{
			case 1:
				return "Low";
			case 2:
				return "Medium";
			default:
				return "High";
		}
	}

	protected string FormatDone(bool isDone)
	{
		return isDone == true ? "Yes" : "No";
	}

	protected void Select_Command(object sender, CommandEventArgs e)
	{
		ListDataSource.SelectParameters["IsComplete"].DefaultValue =
			e.CommandArgument.ToString();
		if (e.CommandName == "show")
			SearchText.Text = "";
		ViewState["CurrentTab"] = e.CommandArgument;
	}

	protected void Page_PreRender(object sender, EventArgs e)
	{
		int i = int.Parse(ViewState["CurrentTab"].ToString());
		ActiveButton.CssClass = i == 0 ? "activeTab" : "tab";
		CompletedButton.CssClass = i == 1 ? "activeTab" : "tab";
		AllButton.CssClass = i == -1 ? "activeTab" : "tab";
		SearchTab.Attributes["class"] = i == -2 ? "activeTab" : "tab";
	}
}
