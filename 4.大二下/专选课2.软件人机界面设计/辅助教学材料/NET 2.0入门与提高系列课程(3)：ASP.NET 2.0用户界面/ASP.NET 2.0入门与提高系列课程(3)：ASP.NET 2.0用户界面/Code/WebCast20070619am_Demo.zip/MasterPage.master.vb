﻿
Partial Class MasterPage
    Inherits System.Web.UI.MasterPage

    Public Property CalVisible() As Boolean
        Get
            Return Calendar1.Visible
        End Get
        Set(ByVal value As Boolean)
            Calendar1.Visible = value
        End Set
    End Property
End Class

