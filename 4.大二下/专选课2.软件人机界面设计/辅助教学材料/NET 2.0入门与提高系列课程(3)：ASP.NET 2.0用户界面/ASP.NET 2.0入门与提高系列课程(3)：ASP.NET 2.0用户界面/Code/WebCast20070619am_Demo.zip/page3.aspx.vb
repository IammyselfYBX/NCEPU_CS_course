﻿
Partial Class page3
    Inherits System.Web.UI.Page

End Class
